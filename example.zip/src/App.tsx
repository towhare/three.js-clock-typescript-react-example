import './App.css';
import ThreeClock from './component/clock'
function App() {
  return (
    <div className="App">
      <ThreeClock />
    </div>
  );
}

export default App;
